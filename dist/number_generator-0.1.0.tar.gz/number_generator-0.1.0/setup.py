# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['number_generator',
 'number_generator.api',
 'number_generator.cli',
 'number_generator.script']

package_data = \
{'': ['*']}

install_requires = \
['fastapi[all]>=0.68.2,<0.69.0',
 'idx2numpy>=1.2.3,<2.0.0',
 'numpy>=1.19.2,<2.0.0',
 'opencv-python==3.4.15.55',
 'typer[all]>=0.4.0,<0.5.0',
 'uvicorn>=0.15.0,<0.16.0',
 'wget>=3.2,<4.0']

entry_points = \
{'console_scripts': ['number-generator = number_generator.cli.cli:app']}

setup_kwargs = {
    'name': 'number-generator',
    'version': '0.1.0',
    'description': 'A simple number sequence generator in python',
    'long_description': "# MNIST Digit Generator\n\nA python library to assist in the training of handwritten digit recognition.\n\n## Usage\nThis library provides several ways to interact with the underlying functionality.\nEach usage style uses the same base code, so which option you choose is just a matter of convenience.\n\nThe primary purpose of this library is to generate images containing a sequence of digits, which originate from the MNIST dataset.\nThese images can then be used in the training pipeline of some model, for an automated source of training / testing data.\n\nThis library relies on poetry as its dependency manager, which is a modern approach to organizing dependencies for python packages.\nYou can find more details about it [here](https://python-poetry.org/).\n\n## Installation\n\nThis library supports multiple ways to install. The simplest way is to install using poetry, which is a modern dependency tracker and environment manager for python.\n\n### Installation with poetry\n\nIf poetry is already installed on your system, simply cd to the root directory of the code, and run:\n\n    poetry install\n\nThis will create a new poetry-managed virtual environment, with all dependencies installed. You can then open this environment by running:\n\n    poetry shell\n\nOr directly run the script by running\n\n    poetry run number-generator\n    \nFor more details about running the code, see below.\n\n### Installation with wheel\n\nIn addition to poetry, which is the recommended installation method, a python wheel is provided for installation. To install, simply cownload the .whl file included in the dist folder. Then (assuming you're in the same folder), run:\n\n    pip install number_generator-0.1.0-py3-none-any.whl\n\nThis will install the library like any other python package.\n\n## Usage as a library\n\nAssuming you've already got in installed, its now ready to be imported, as:\n\n    from number_generator import generate_numbers_sequence, generate_phone_number\n\nThis interface provides two main functions:\n- `generate_numbers_sequence`\n- `generate_phone_number`\n\nThese functions handle two different ways of image generation, with full type-hints and docstrings explaining their usage.\n\n## Usage from the command line\n\nAssuming you've already got in installed, this library can be used from the command line in a few ways, depending on installation.\n\nIf you've installed it through poetry, in a poetry virtual environment, you can run:\n\n    poetry run number-generator --help\n\nOtherwise, if installed as a normal python package, you can run:\n\n    python -m number-generator --help\n\nFor full information on how to run this from the command line, run one of the above commands to see the help, which will walk you through the script usage. This commandline interface is provided via the `typer` library, and is a modern approach to making auto-documenting CLIs in python.\n\n## Usage as an API\n\nUnlike the other two use-cases, using this as a library does not involve installing the library, but instead involves running a docker container using the included `Dockerfile`.\n\nTo compose this container:\n- Download the source code\n- CD to the root folder of the source code\n- RUN `docker build -t digitgenerator .`\n- RUN `docker run -p 8085:80 digitgenerator`\n- In a browser, go to [localhost:8085/docs](http://localhost:8085/docs) to view the interactive documentation.\n\nIn addition to this browser window, the API is now accessible from the ip address you've run this docker image from. Ensure functionality by manually using the web documentation first before relying on it in production.\n\nThis API is build using `FastAPI`, a modern API framework in python, that provides plentiful auto-documentation, and many conveniences that other libraries like `flask` don't. \n",
    'author': 'Trevor Wieland',
    'author_email': 'trevor_wieland@mac.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6.1,<4.0.0',
}


setup(**setup_kwargs)
