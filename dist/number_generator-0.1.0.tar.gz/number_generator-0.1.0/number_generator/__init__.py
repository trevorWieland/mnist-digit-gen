from .script.generate import generate_numbers_sequence
from .script.generate import generate_phone_number
